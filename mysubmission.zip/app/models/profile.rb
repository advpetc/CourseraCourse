class Profile < ActiveRecord::Base
  belongs_to :user

  validates :gender, inclusion: { in: %w(male female) }
  validate :fname_or_lname_exist
  validate :sue_case
  def fname_or_lname_exist
      if not first_name.present? and not last_name.present?
          errors.add(:first_name, "first name and last name cannot be null at the same time.")
      end
  end

  def sue_case
      if first_name.eql? "Sue" and gender.eql? "male"
        errors.add(:first_name, "male cannot be Sue")
      end
  end

  def self.get_all_profiles(min_by, max_by)
      Profile.where('birth_year BETWEEN ? AND ?', min_by, max_by).order('birth_year ASC')
  end
end
