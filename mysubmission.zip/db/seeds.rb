# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)

TodoItem.destroy_all
TodoList.destroy_all
Profile.destroy_all
User.destroy_all

profiles = Profile.create! [
  { gender: 'female', birth_year: 1954, first_name: 'Carly', last_name: 'Fiorina' },
  { gender: 'male', birth_year: 1946, first_name: 'Donald', last_name: 'Trump' },
  { gender: 'male', birth_year: 1951, first_name: 'Ben', last_name: 'Carson' },
  { gender: 'female', birth_year: 1947, first_name: 'Hillary', last_name: 'Clinton' }
]

profiles.each do |p|
  p.create_user! username: p.last_name, password_digest: p.birth_year
  l = p.user.todo_lists.create! list_name: "#{p.first_name}'s list", list_due_date: Date.today + 1.year
  5.times do
    l.todo_items.create! due_date: Date.today + 1.year, title: 'random title', description: 'random description'
  end
end
